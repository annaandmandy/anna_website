package com.onsen.onsen_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnsenBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
